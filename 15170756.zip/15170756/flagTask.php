
<!DOCTYPE html>
<html>
	<head>
		<title>Banning a user</title>
		<link href="DaithiCSS.css" rel="stylesheet" type="text/css">	
	
	</head>
	<header>
<div id="header">
  <a href= "userTasks.php">My Tasks</a>
   <a href= "index.php">All Tasks</a>
   <a href= "banUser.php">Ban User</a>
   <a href= "logout.php">Logout</a>
  </div>
	<body>
		<div class="header" id="headerB">
			<h1>Header</h1>
		</div> 
<?php
$servername = "localhost";
$username = "group14";
$password = "since-WATER-MUCH-arms";
$dbname = "group14";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if(!$conn){
		echo"unable to connect to database";
	}
	else {
			echo"you are connected\n";
	}
 
			if (!isset($_POST)||count($_POST)>0){
			$flagTaskReason = $_POST['flagTaskReason'];
			$userId = $_POST['user_ID'];

			$query =  mysqli_query($conn,"INSERT INTO `flagged_tasks`(`Task_Title`,`task_ID`, `user_ID`, `reason`)
			VALUES ('books','1531','15','$flagTaskReason');");
			$queryTWO =  mysqli_query($conn,"UPDATE `user_profile` SET `score`= score + 2 WHERE User_ID = '15161277';");
			if($query) {
				echo "Added to database";
			}
			else {
				echo "Not Added to database";
			}
				
		}
	else{
?> 
		<br>	
			<form action="" method = "post">
			<form method="post" target="">
			Please enter your reason for flagging this task.	
				<input type="text" name="flagTaskReason" id="flagTaskReason" style="width: 200px"><br>
				<input type="submit" value="flag task">
			</form>

			
		<div class="footer" id="footerB">
			<p>Footer</p>
		</div>
		<?php } ?>
	</body>
</html>	