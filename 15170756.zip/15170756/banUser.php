<?php 
	if (!isset ($_SESSION)) {
		session_start();
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Banning a user</title>
		<link href="DaithiCSS.css" rel="stylesheet" type="text/css">	
	
	</head>
	<header>
<div id="header">
  <a href= "userTasks.php">My Tasks</a>
   <a href= "index.php">All Tasks</a>
   <a href= "banUser.php">Ban User</a>
   <a href= "logout.php">Logout</a>
  </div>
	<body>
		<div class="header" id="headerB">
			<h1>Header</h1>
		</div>
		<?php
$servername = "localhost";
$username = "group14";
$password = "since-WATER-MUCH-arms";
$dbname = "group14";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT User_id, first_name, last_name FROM user_profile";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         echo "<br> User id: ". $row["User_id"]. " - Name: ". $row["first_name"]. " " . $row["last_name"] . "<br>";
     }
} else {
     echo "0 results";
}

$conn->close();
?> 
<?php
$servername = "localhost";
$username = "group14";
$password = "since-WATER-MUCH-arms";
$dbname = "group14";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if(!$conn){
		echo"unable to connect to database";
	}
	else {
			echo"you are connected\n";
	}
 
			if (!isset($_POST)||count($_POST)>0){
			$banId = $_POST['banId'];
			$banReason = stripslashes($_POST['banReason']);

			$query =  mysqli_query($conn,"INSERT INTO `banned_users`(`user_ID`, `Moderator_ID`, `reason`)
			VALUES ('$banId','".$_SESSION['users_id']."','$banReason');");
			$queryTwo = mysqli_query($conn,"DELETE FROM `user_profile` Where User_ID = '$banId'");
			if($query) {
				echo "Added to database";
			}
			else {
				echo "Not Added to database";
			}
				
		}
	else{
?> 
		<br>	
			<form action="" method = "post">
			<form method="post" target="">
			Please enter the ID below of the person you wish to ban.
				<input type="number" name="banId" id="banid" style="width: 200px"><br>
			Please enter your reason for banning this person.	
				<input type="text" name="banReason" id="banReason" style="width: 200px"><br>
				<input type="submit" value="Ban User">
			</form>

			
		<div class="footer" id="footerB">
			<p>Footer</p>
		</div>
		<?php } ?>
	</body>
</html>	